from groq import Groq
from dotenv import load_dotenv
import os

load_dotenv()

client = Groq(api_key=os.getenv("GROQ_API_KEY"))


def generate_story(topic, genre, length):

    # 🔥 Length mapping
    if length == "Short":
        word_limit = "300-500 words"
    elif length == "Medium":
        word_limit = "700-1000 words"
    else:
        word_limit = "1200-1500 words"

    prompt = f"""
    Write a {length} {genre} story about {topic}.

    IMPORTANT REQUIREMENTS:
    - Length must be strictly around {word_limit}
    - Do NOT exceed limit
    - Must be well structured
    - Simple English
    - Engaging story with clear ending
    """

    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content