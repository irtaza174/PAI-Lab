import requests
import os
from PIL import Image
from io import BytesIO


def generate_image(prompt):

    url = f"https://image.pollinations.ai/prompt/{prompt}"

    response = requests.get(url)

    img = Image.open(BytesIO(response.content))

    save_dir = os.path.join("static", "generated")
    os.makedirs(save_dir, exist_ok=True)

    file_path = os.path.join(save_dir, "generated_image.jpg")
    img.save(file_path)

    return "/" + file_path.replace("\\", "/")