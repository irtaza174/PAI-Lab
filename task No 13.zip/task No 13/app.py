from flask import Flask, render_template, request
from utils.story_generator import generate_story
from utils.image_generator import generate_image
import os

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/generate', methods=['POST'])
def generate():
    try:
        topic = request.form['topic']
        genre = request.form['genre']
        length = request.form['length']

        story = generate_story(topic, genre, length)

        image_prompt = f"{topic}, {genre}, cinematic digital art"
        image_path = generate_image(image_prompt)

        return render_template(
            'result.html',
            story=story,
            image=image_path,
            topic=topic
        )

    except Exception as e:
        return f"<h2>Error Occurred</h2><pre>{str(e)}</pre>"


if __name__ == '__main__':
    print("Flask starting...")
    app.run(debug=True)