from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Hotel Data
hotel_data = {
    "rooms": {
        "single": {"price": 50, "amenities": ["WiFi", "TV", "AC"]},
        "double": {"price": 80, "amenities": ["WiFi", "TV", "AC", "Mini Bar"]},
        "suite": {"price": 150, "amenities": ["WiFi", "TV", "AC", "Mini Bar", "Jacuzzi"]}
    },
    "booking": "You can book a room by calling +123456789 or visiting our website."
}

# Chatbot Logic
def get_bot_response(user_input):
    user_input = user_input.lower()

    if "room" in user_input:
        return "We offer Single, Double, and Suite rooms."
    
    elif "price" in user_input:
        return "Prices are: Single $50, Double $80, Suite $150 per night."
    
    elif "amenities" in user_input:
        return "Rooms include WiFi, TV, AC. Suites also have Jacuzzi."
    
    elif "book" in user_input:
        return hotel_data["booking"]
    
    else:
        return "Sorry, I didn't understand. Ask about rooms, prices, amenities, or booking."

# Routes
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json["message"]
    response = get_bot_response(user_message)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)